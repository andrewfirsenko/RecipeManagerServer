package data;

public enum Category {
    BREAKFAST,
    LUNCH,
    DINNER,
    DESSERT
}
